# Billy Bakery — website

Static website for Billy Bakery NPC, a non-profit bakery in Hatfield, Pretoria.
Built for the WEDE5020 Portfolio of Evidence with HTML5, CSS3 and vanilla JavaScript.

## Files

```
billy-bakery/
├── index.html        Home — hero, where the money goes, ways to help
├── about.html        Organisation overview, mission, vision, history, audience
├── products.html     Full pastry and catering list with a working filter
├── contact.html      Contact details, hours, validated enquiry form
├── css/
│   └── style.css     All styling (design tokens at the top)
├── js/
│   ├── main.js       Mobile nav, animated menu filter, form validation, footer year
│   ├── animations.js Page-load reveal, scroll progress, scroll reveals, counters, live tray, tilt
│   └── maps.js       Leaflet maps: delivery zones (contact) and story map (about)
├── images/           Empty — drop your own photos here
└── README.md
```

## Running it in Visual Studio Code

1. Open the `billy-bakery` folder in VS Code (**File → Open Folder**).
2. Easiest way: right-click `index.html` in the Explorer and choose **Open with Live Server**.
   If you don't have it, install the **Live Server** extension by Ritwick Dey from the Extensions panel.
3. Without Live Server, just double-click `index.html` in your file manager — everything uses
   relative paths, so it runs straight off the file system.

No build step, no npm, no frameworks.

## Fonts

Archivo and Newsreader load from Google Fonts, so the first load needs internet.
Offline, the site falls back to Helvetica/Arial and Georgia and still looks correct.

## Images

The `images/` folder holds 24 **SVG placeholders** — flat illustrations in the site
palette with the item name printed on them. They are real files, so nothing appears
broken offline, but they are stand-ins for photographs.

**Replacing one with a real photo:**

1. Crop your photo to **3:2** (e.g. 1200 × 800) and save it as JPG at around 150–250 KB.
2. Drop it in `images/` using the same name, e.g. `butter-croissant.jpg`.
3. Change the `src` in the HTML from `.svg` to `.jpg`. That's the only edit —
   the CSS box, border and cropping stay the same.
4. Rewrite the `alt` text to describe *that* photo. Markers check this.

Every `<img>` already has `alt`, `width`, `height` and `loading="lazy"`, so the layout
doesn't jump while images load.

**Where to get photos you're allowed to use:** Unsplash, Pexels and Pixabay are free
for commercial use with no attribution required. Search "bakery counter", "croissant
tray", "pastry chef hands". Record where each one came from — most POE rubrics want an
image source list. Better still, photograph a real bakery yourself; it will look more
honest than stock.

`make_placeholders.py` (in the project root) is the script that generated the SVGs, if
you ever need to regenerate or add one.

## Design tokens

Change the look from one place — the `:root` block at the top of `css/style.css`:

| Token | Value | Used for |
|---|---|---|
| `--ink` | `#13212B` | text, borders, dark sections |
| `--chalk` | `#E8EEEF` | page background |
| `--paper` | `#FBF9F4` | cards, header, form fields |
| `--butter` | `#F5C043` | primary buttons, hard shadow, accents |
| `--jam` | `#7C2B4C` | links, prices, emphasis |

Type: **Archivo** 500–800 for headings and UI, **Newsreader** 400–500 for body copy.

## Maps

Two interactive maps, both built with **Leaflet 1.9.4** (loaded from the unpkg CDN on
`contact.html` and `about.html` only).

| Map | Page | What it does |
|---|---|---|
| Delivery map | `contact.html` | Shop, Gautrain station and partner shelter pins; two delivery zones (5 km and 12 km) that grow outward when the map scrolls into view; a suburb picker and a **Use my location** button that measure the straight-line distance and say which zone you are in; layer toggles; reset. |
| Story map | `about.html` | The 2016 church kitchen, the 2021 shopfront and the night shelter. Routes between them draw themselves, and the buttons fly the map from place to place. |

**Why Leaflet.** Mapbox and Google Maps both need an API key and a billing account, and a key
pasted into a student project is a key anyone can copy. Leaflet is free, needs no key, and
the tiles (CARTO and OpenStreetMap) are free for light use with attribution, which Leaflet
adds for you. If your lecturer specifically wants Mapbox or Google Maps, the structure carries
over: the pins, popups, zones and the suburb/distance logic in `maps.js` are what you would
re-create with their SDK, and `PLACES` / `SUBURBS` at the top stay the same.

**Editing the places.** `PLACES` and `SUBURBS` at the top of `js/maps.js` hold every
coordinate. They are approximate points around Hatfield, so replace them with real ones
(right-click a spot in Google Maps and copy the latitude and longitude). The zone sizes
are `ZONE1_KM` and `ZONE2_KM`. The delivery fees in the zone text are placeholders.

**Needs internet.** The map and its tiles load from a CDN. With no connection (or if the
CDN is blocked) the map area shows a message with links to Google Maps and OpenStreetMap,
and the suburb / distance checker keeps working because it is plain maths.

**Use my location** needs a secure context. It works on `localhost` (Live Server) and on
any HTTPS host, but browsers may block it when you open the file straight from disk.

## Animations

All motion is CSS transforms (translate, scale, rotate, perspective) set or triggered by JavaScript.

| Effect | Where | How |
|---|---|---|
| Headline words rise from a mask | every hero | JS splits the title into words; CSS `translateY` with a per-word delay |
| Scroll progress bar | every page | `scaleX` from 0 to 1 as you scroll |
| Scroll reveals | cards, photos, timeline, menu items | `IntersectionObserver` adds a class; items slide or zoom in with a staggered delay |
| Count-up figures | home page | `requestAnimationFrame` easing from 0 to 24, 81%, 11 400, R1.9m |
| Cost-split bar | home page | a curtain slides away with `translateX` |
| Live tray | home page | reads the time in Pretoria and marks each bake **Out now**, upcoming, or done; the heading shows open / closed |
| 3D tilt | tray board, feature photos | `perspective` + `rotateX/Y` follow the pointer |
| Animated filter | products page | cards scale and fade out, others scale back in one after another |
| Pins, zones, routes | maps | pins drop in with a CSS animation; zone radius and route lines are animated in JS |
| Form feedback | contact page | invalid fields shake; the success message pops in |

**Accessibility.** Users who ask their system for reduced motion get none of this: the
words, reveals, counters, tilt and pin drops are all skipped and everything is shown at once.
If JavaScript fails entirely, nothing is left hidden.

## What the other JavaScript does

- **Mobile menu** — the Menu button toggles the nav under 860px and updates `aria-expanded`.
- **Form validation** — checks name length, email pattern, selected reason and message
  length on submit, shows inline errors, moves focus to the first problem field, and
  confirms on success. There is no backend, so nothing is actually emailed.

## Accessibility and responsiveness

- Skip link, visible keyboard focus rings, labelled form fields with `aria-live` errors.
- `prefers-reduced-motion` respected.
- Breakpoints at 860px and 520px; fluid type with `clamp()` in between.
- Print stylesheet strips navigation and footer.

## POE sections this covers

| Brief section | Where |
|---|---|
| 1. Organisation overview | `about.html` — who we are, mission, vision, history, audience |
| 2. Goals and KPIs | `index.html` — "Our year so far" figures |
| 4. Features and functionality | Four pages, nav, animated filter, contact form, two interactive maps with a delivery-zone checker |
| 5. Design and user experience | Palette and type documented above |
| 6. Technical requirements | HTML5, CSS3, JavaScript, Leaflet 1.9.4 (CDN); static host, no server needed |
