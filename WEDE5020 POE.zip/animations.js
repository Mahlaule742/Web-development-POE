/* =========================================================
   Billy Bakery — animations.js
   Everything here moves with CSS transforms (translate, scale,
   rotate, perspective) driven by JavaScript.

   1. Pure helpers (also unit-tested in Node)
   2. Page-load: headline words rise, then body gets .is-ready
   3. Scroll progress bar (scaleX) + header shadow
   4. Scroll reveals (IntersectionObserver)
   5. Count-up figures
   6. Cost-split bar curtain
   7. Live "out of the oven" tray, on Pretoria time
   8. Pointer tilt (3D rotate)

   Respects prefers-reduced-motion: nothing here runs for those users
   except the scroll progress bar, which only follows their own scrolling.
   ========================================================= */
(function () {
  'use strict';

  /* ---------- 1. Pure helpers ---------- */

  // Opening hours in minutes after midnight: [open, close]. Sunday is closed.
  function openWindow(day) {
    if (day === 0) { return null; }
    if (day === 6) { return [7 * 60, 14 * 60]; }
    return [6 * 60 + 30, 17 * 60];
  }

  function clock(mins) {
    var h = Math.floor(mins / 60);
    var m = mins % 60;
    return (h < 10 ? '0' : '') + h + ':' + (m < 10 ? '0' : '') + m;
  }

  // Day-of-week and minutes-after-midnight in Pretoria, wherever the visitor is.
  function pretoriaNow(date) {
    var d = date || new Date();
    try {
      var parts = new Intl.DateTimeFormat('en-GB', {
        timeZone: 'Africa/Johannesburg',
        weekday: 'short',
        hour: '2-digit',
        minute: '2-digit',
        hourCycle: 'h23'
      }).formatToParts(d);
      var pick = function (type) {
        return parts.filter(function (p) { return p.type === type; })[0].value;
      };
      var days = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };
      return {
        day: days[pick('weekday')],
        mins: parseInt(pick('hour'), 10) * 60 + parseInt(pick('minute'), 10)
      };
    } catch (err) {
      return { day: d.getDay(), mins: d.getHours() * 60 + d.getMinutes() };
    }
  }

  // itemMinutes: bake times as minutes after midnight, one per tray row.
  // Returns a short label for the header and a state per row: out | later | done
  function trayStatus(now, itemMinutes) {
    var win = openWindow(now.day);
    var all = function (state) { return itemMinutes.map(function () { return state; }); };

    if (!win) { return { label: 'Closed today', states: all('later') }; }
    if (now.mins < win[0]) { return { label: 'Opens ' + clock(win[0]), states: all('later') }; }
    if (now.mins >= win[1]) { return { label: 'Closed for the day', states: all('done') }; }

    return {
      label: 'Open until ' + clock(win[1]),
      states: itemMinutes.map(function (t) { return t <= now.mins ? 'out' : 'later'; })
    };
  }

  // 11400 -> "11 400" (non-breaking space, South African style)
  function formatNumber(value, decimals) {
    var fixed = value.toFixed(decimals).split('.');
    var whole = fixed[0].replace(/\B(?=(\d{3})+(?!\d))/g, '\u00a0');
    return decimals > 0 ? whole + '.' + fixed[1] : whole;
  }

  if (typeof document === 'undefined') {
    if (typeof module !== 'undefined' && module.exports) {
      module.exports = { openWindow: openWindow, clock: clock, pretoriaNow: pretoriaNow,
        trayStatus: trayStatus, formatNumber: formatNumber };
    }
    return; // running under Node for tests: stop before touching the DOM
  }

  var reduceMotion = window.matchMedia &&
    window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var canObserve = 'IntersectionObserver' in window;

  /* ---------- 2. Page-load: headline words ---------- */

  // Wraps every word in a masked span so it can slide up from below its own baseline.
  function splitWords(el) {
    var index = 0;
    // innerText follows the layout, so "croissant." and "Pay a wage." stay two sentences
    el.setAttribute('aria-label', (el.innerText || el.textContent).replace(/\s+/g, ' ').trim());

    (function walk(node) {
      Array.prototype.slice.call(node.childNodes).forEach(function (child) {
        if (child.nodeType === 3) {
          var frag = document.createDocumentFragment();
          child.textContent.split(/(\s+)/).forEach(function (part) {
            if (!part) { return; }
            if (/^\s+$/.test(part)) { frag.appendChild(document.createTextNode(' ')); return; }
            var outer = document.createElement('span');
            var inner = document.createElement('span');
            outer.className = 'word';
            inner.textContent = part;
            inner.style.setProperty('--i', index++);
            outer.appendChild(inner);
            frag.appendChild(outer);
          });
          child.parentNode.replaceChild(frag, child);
        } else if (child.nodeType === 1) {
          walk(child);
        }
      });
    })(el);

    el.classList.add('split-line');
  }

  var heroTitle = document.querySelector('.hero h1');
  if (heroTitle && !reduceMotion) { splitWords(heroTitle); }

  // Two frames, so the browser paints the "before" state first and the
  // transition has something to animate from.
  requestAnimationFrame(function () {
    requestAnimationFrame(function () { document.body.classList.add('is-ready'); });
  });

  /* ---------- 3. Scroll progress + header ---------- */

  var progress = document.createElement('div');
  progress.className = 'scroll-progress';
  progress.setAttribute('aria-hidden', 'true');
  document.body.appendChild(progress);

  var header = document.querySelector('.site-header');
  var ticking = false;

  function onScroll() {
    if (ticking) { return; }
    ticking = true;
    requestAnimationFrame(function () {
      var max = document.documentElement.scrollHeight - window.innerHeight;
      var p = max > 0 ? window.scrollY / max : 0;
      progress.style.transform = 'scaleX(' + Math.min(1, Math.max(0, p)) + ')';
      if (header) { header.classList.toggle('is-scrolled', window.scrollY > 8); }
      ticking = false;
    });
  }

  window.addEventListener('scroll', onScroll, { passive: true });
  window.addEventListener('resize', onScroll);
  onScroll();

  /* ---------- 4. Scroll reveals ---------- */

  // [selector, direction]. No HTML changes needed: this list decides what animates.
  var REVEALS = [
    ['.section-intro', 'up'],
    ['.section h2', 'up'],
    ['.card', 'up'],
    ['.menu-item', 'up'],
    ['.timeline li', 'left'],
    ['.photo', 'zoom'],
    ['.figures > div', 'up'],
    ['.split-key', 'up'],
    ['.detail-list li', 'up'],
    ['.hours', 'up'],
    ['.map-panel', 'left'],
    ['.map-frame', 'right'],
    ['.map-steps', 'up']
  ];

  function setupReveals() {
    if (reduceMotion || !canObserve) { return; }

    var seen = [];
    var perParent = [];   // [parentNode, count]
    var targets = [];

    REVEALS.forEach(function (rule) {
      Array.prototype.forEach.call(document.querySelectorAll(rule[0]), function (el) {
        if (seen.indexOf(el) !== -1 || el.closest('.hero')) { return; }
        seen.push(el);

        // Already on screen when the page loads: leave it alone.
        var rect = el.getBoundingClientRect();
        if (rect.top < window.innerHeight * 0.9 && rect.bottom > 0) { return; }

        var slot = null;
        for (var i = 0; i < perParent.length; i++) {
          if (perParent[i][0] === el.parentNode) { slot = perParent[i]; break; }
        }
        if (!slot) { slot = [el.parentNode, 0]; perParent.push(slot); }

        el.setAttribute('data-reveal', rule[1]);
        el.style.setProperty('--reveal-delay', (slot[1] % 4) * 90 + 'ms');
        slot[1] += 1;
        targets.push(el);
      });
    });

    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) { return; }
        var el = entry.target;
        io.unobserve(el);
        el.classList.add('is-visible');
        // Once it has landed, hand transitions back to the element's own CSS (hover etc.)
        setTimeout(function () {
          el.removeAttribute('data-reveal');
          el.style.removeProperty('--reveal-delay');
        }, 1400);
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -6% 0px' });

    targets.forEach(function (el) { io.observe(el); });
  }

  /* ---------- 5. Count-up figures ---------- */

  function runCounter(el) {
    var target = parseFloat(el.getAttribute('data-count'));
    var decimals = parseInt(el.getAttribute('data-decimals') || '0', 10);
    var prefix = el.getAttribute('data-prefix') || '';
    var suffix = el.getAttribute('data-suffix') || '';
    var duration = 1700;
    var start = null;

    function frame(now) {
      if (start === null) { start = now; }
      var t = Math.min(1, (now - start) / duration);
      var eased = 1 - Math.pow(1 - t, 3); // ease-out cubic
      el.textContent = prefix + formatNumber(target * eased, decimals) + suffix;
      if (t < 1) { requestAnimationFrame(frame); }
    }
    requestAnimationFrame(frame);
  }

  function setupCounters() {
    var counters = document.querySelectorAll('[data-count]');
    if (!counters.length || reduceMotion || !canObserve) { return; }

    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) { return; }
        io.unobserve(entry.target);
        runCounter(entry.target);
      });
    }, { threshold: 0.6 });

    Array.prototype.forEach.call(counters, function (el) {
      el.textContent = (el.getAttribute('data-prefix') || '') + '0' + (el.getAttribute('data-suffix') || '');
      io.observe(el);
    });
  }

  /* ---------- 6. Cost-split bar ---------- */

  function setupSplitBar() {
    var bars = document.querySelectorAll('.split-bar');
    if (!bars.length) { return; }
    if (reduceMotion || !canObserve) {
      Array.prototype.forEach.call(bars, function (b) { b.classList.add('in-view'); });
      return;
    }
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) { return; }
        entry.target.classList.add('in-view');
        io.unobserve(entry.target);
      });
    }, { threshold: 0.6 });
    Array.prototype.forEach.call(bars, function (b) { io.observe(b); });
  }

  /* ---------- 7. Live tray ---------- */

  function setupTray() {
    var rows = document.querySelectorAll('.tray-list li');
    var label = document.querySelector('.tray-date');
    if (!rows.length) { return; }

    var minutes = Array.prototype.map.call(rows, function (row) {
      var bits = row.querySelector('.tray-time').textContent.split(':');
      return parseInt(bits[0], 10) * 60 + parseInt(bits[1], 10);
    });

    function refresh() {
      var status = trayStatus(pretoriaNow(), minutes);
      if (label) { label.textContent = status.label; }
      Array.prototype.forEach.call(rows, function (row, i) {
        row.setAttribute('data-state', status.states[i]);
      });
    }

    refresh();
    setInterval(refresh, 60 * 1000);
  }

  /* ---------- 8. Pointer tilt ---------- */

  function setupTilt() {
    if (reduceMotion || !window.matchMedia('(hover: hover)').matches) { return; }

    Array.prototype.forEach.call(document.querySelectorAll('.tray, .photo-feature'), function (el) {
      el.setAttribute('data-tilt', '');

      el.addEventListener('pointermove', function (e) {
        var r = el.getBoundingClientRect();
        var x = (e.clientX - r.left) / r.width - 0.5;
        var y = (e.clientY - r.top) / r.height - 0.5;
        el.style.transform = 'perspective(900px) rotateY(' + (x * 6).toFixed(2) +
          'deg) rotateX(' + (-y * 6).toFixed(2) + 'deg)';
      });

      el.addEventListener('pointerleave', function () { el.style.transform = ''; });
    });
  }

  setupReveals();
  setupCounters();
  setupSplitBar();
  setupTray();
  setupTilt();
})();
