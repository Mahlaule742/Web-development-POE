/* =========================================================
   Billy Bakery — maps.js
   Built on Leaflet 1.9.4. No API key, no billing: Leaflet is free
   and the tiles come from CARTO / OpenStreetMap.

   Two maps:
   · #map-find   (contact.html)  the shop, the station, the shelter, two
                 animated delivery zones, a "check my suburb" tool and
                 a "use my location" button that measures the distance.
   · #map-story  (about.html)    the 2016 church kitchen, the 2021 shop and
                 the night shelter, joined by routes that draw themselves.

   Coordinates are approximate placeholders around Hatfield, Pretoria.
   Change them in PLACES below to match your real client.
   ========================================================= */
(function () {
  'use strict';

  /* ---------- Data ---------- */

  var PLACES = {
    shop: {
      name: 'Billy Bakery', icon: '\uD83E\uDD50', lat: -25.7494, lng: 28.2368,
      text: '14 Burnett Street, corner of Hilda Street.<br>Mon\u2013Fri 06:30\u201317:00 \u00B7 Sat 07:00\u201314:00'
    },
    station: {
      name: 'Hatfield Gautrain station', icon: '\uD83D\uDE86', lat: -25.7487, lng: 28.2384,
      text: 'Two blocks from the shop on foot.'
    },
    shelter: {
      name: 'Hatfield night shelter', icon: '\uD83C\uDFE0', lat: -25.7568, lng: 28.2402,
      text: 'Collects every unsold tray at 17:00.'
    },
    kitchen: {
      name: "St Wilfrid's church kitchen", icon: '\u26EA', lat: -25.7525, lng: 28.2335,
      text: '2016: one oven, one Saturday a week.'
    }
  };

  var SUBURBS = [
    { name: 'Arcadia',      lat: -25.7470, lng: 28.2060 },
    { name: 'Sunnyside',    lat: -25.7550, lng: 28.2080 },
    { name: 'Brooklyn',     lat: -25.7690, lng: 28.2380 },
    { name: 'Menlo Park',   lat: -25.7690, lng: 28.2670 },
    { name: 'Waterkloof',   lat: -25.7880, lng: 28.2350 },
    { name: 'Lynnwood',     lat: -25.7560, lng: 28.2860 },
    { name: 'Menlyn',       lat: -25.7850, lng: 28.2790 },
    { name: 'Garsfontein',  lat: -25.7900, lng: 28.3170 },
    { name: 'Centurion',    lat: -25.8603, lng: 28.1894 }
  ];

  var ZONE1_KM = 5;
  var ZONE2_KM = 12;

  var COLOURS = { ink: '#13212B', butter: '#F5C043', jam: '#7C2B4C' };

  /* ---------- Pure helpers (unit-tested in Node) ---------- */

  function haversineKm(a, b) {
    var R = 6371;
    var rad = function (d) { return d * Math.PI / 180; };
    var dLat = rad(b.lat - a.lat);
    var dLng = rad(b.lng - a.lng);
    var s = Math.pow(Math.sin(dLat / 2), 2) +
      Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.pow(Math.sin(dLng / 2), 2);
    return 2 * R * Math.asin(Math.sqrt(s));
  }

  function zoneFor(km) {
    if (km <= ZONE1_KM) {
      return { id: 1, text: 'That is Zone 1: free delivery on platter orders over R500.' };
    }
    if (km <= ZONE2_KM) {
      return { id: 2, text: 'That is Zone 2: a flat R80 delivery fee.' };
    }
    return { id: 0, text: 'That is outside our delivery area. Phone us on 012 123 4567 and we will see what we can do.' };
  }

  if (typeof document === 'undefined') {
    if (typeof module !== 'undefined' && module.exports) {
      module.exports = { haversineKm: haversineKm, zoneFor: zoneFor, PLACES: PLACES, SUBURBS: SUBURBS };
    }
    return; // running under Node for tests
  }

  /* ---------- Shared map helpers ---------- */

  var reduceMotion = window.matchMedia &&
    window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  // Runs onFrame(0..1, eased) over `duration` ms.
  function tween(duration, onFrame, done) {
    if (reduceMotion) { onFrame(1); if (done) { done(); } return; }
    var start = null;
    function step(now) {
      if (start === null) { start = now; }
      var t = Math.min(1, (now - start) / duration);
      onFrame(1 - Math.pow(1 - t, 3));
      if (t < 1) { requestAnimationFrame(step); } else if (done) { done(); }
    }
    requestAnimationFrame(step);
  }

  function whenVisible(el, run) {
    if (!('IntersectionObserver' in window)) { run(); return; }
    var io = new IntersectionObserver(function (entries) {
      if (entries[0].isIntersecting) { io.disconnect(); run(); }
    }, { threshold: 0.25 });
    io.observe(el);
  }

  function showFallback(el) {
    var s = PLACES.shop;
    el.innerHTML =
      '<div class="map-fallback"><p><strong>The interactive map needs an internet connection.</strong></p>' +
      '<p>Billy Bakery is at 14 Burnett Street, Hatfield, Pretoria.</p>' +
      '<p><a href="https://www.google.com/maps/search/?api=1&amp;query=' + s.lat + ',' + s.lng + '" target="_blank" rel="noopener">Open in Google Maps</a> \u00B7 ' +
      '<a href="https://www.openstreetmap.org/?mlat=' + s.lat + '&amp;mlon=' + s.lng + '#map=17/' + s.lat + '/' + s.lng + '" target="_blank" rel="noopener">Open in OpenStreetMap</a></p></div>';
  }

  function addBaseLayers(map, el) {
    var credit = '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors';
    var clean = L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png', {
      subdomains: 'abcd', maxZoom: 19,
      attribution: credit + ' &copy; <a href="https://carto.com/attributions">CARTO</a>'
    });
    var street = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19, attribution: credit
    });

    clean.addTo(map);
    L.control.layers({ 'Clean': clean, 'Street detail': street }, null, { collapsed: true }).addTo(map);

    var warned = false;
    [clean, street].forEach(function (layer) {
      layer.on('tileerror', function () {
        if (warned) { return; }
        warned = true;
        var note = document.createElement('p');
        note.className = 'map-note';
        note.textContent = 'Some map tiles could not load. Check your connection and refresh the page.';
        el.parentNode.appendChild(note);
      });
    });
  }

  // A pin that drops in with a CSS transform. `variant` picks the colour.
  function pinIcon(place, delay, variant, pulse) {
    return L.divIcon({
      className: 'pin-icon',
      html: '<div class="pin-drop" style="--d:' + delay + 'ms">' +
        (pulse ? '<span class="pulse-ring"></span>' : '') +
        '<div class="pin-shadow"><div class="pin ' + (variant || '') + '"><span>' + place.icon + '</span></div></div></div>',
      iconSize: [38, 38],
      iconAnchor: [19, 46],
      popupAnchor: [0, -44]
    });
  }

  function popupHtml(place) {
    var dir = 'https://www.google.com/maps/dir/?api=1&destination=' + place.lat + ',' + place.lng;
    return '<div class="map-popup"><h4>' + place.name + '</h4><p>' + place.text + '</p>' +
      '<a href="' + dir + '" target="_blank" rel="noopener">Get directions \u2197</a></div>';
  }

  function makeMarker(place, delay, variant, pulse) {
    return L.marker([place.lat, place.lng], {
      icon: pinIcon(place, delay, variant, pulse),
      title: place.name,
      riseOnHover: true
    }).bindPopup(popupHtml(place));
  }

  // Scroll wheel only zooms once the visitor has clicked into the map,
  // so scrolling down the page never gets hijacked.
  function guardWheel(map) {
    map.scrollWheelZoom.disable();
    map.on('click focus', function () { map.scrollWheelZoom.enable(); });
    map.on('mouseout blur', function () { map.scrollWheelZoom.disable(); });
  }

  /* ---------- Contact page: delivery checker ----------
     The panel (suburb chips, "use my location", reset, layer toggles) is wired
     separately from the map. Distances and zones are plain maths, so the checker
     still answers if Leaflet or its tiles fail to load. `view` is how the panel
     talks to the map; offline it is a set of do-nothing functions. */

  function wireDeliveryPanel(view) {
    var statusEl = document.getElementById('map-status');
    var defaultStatus = statusEl ? statusEl.textContent : '';

    function say(html) {
      if (!statusEl) { return; }
      statusEl.innerHTML = html;
      statusEl.classList.remove('is-updated');
      void statusEl.offsetWidth; // restart the animation
      statusEl.classList.add('is-updated');
    }

    function report(label, verb, point) {
      var km = haversineKm(PLACES.shop, point);
      view.show(point, label);
      say('<strong>' + label + ' ' + verb + ' ' + km.toFixed(1) + ' km from the shop</strong> in a straight line. ' + zoneFor(km).text);
    }

    // Suburb chips
    var chipList = document.getElementById('suburb-chips');
    var chips = [];
    if (chipList) {
      SUBURBS.forEach(function (suburb) {
        var chip = document.createElement('button');
        chip.type = 'button';
        chip.className = 'chip';
        chip.textContent = suburb.name;
        chip.setAttribute('aria-pressed', 'false');
        chip.addEventListener('click', function () {
          chips.forEach(function (c) {
            c.classList.toggle('is-active', c === chip);
            c.setAttribute('aria-pressed', c === chip ? 'true' : 'false');
          });
          report(suburb.name, 'is', suburb);
        });
        chips.push(chip);
        chipList.appendChild(chip);
      });
    }

    function deactivateChips() {
      chips.forEach(function (c) { c.classList.remove('is-active'); c.setAttribute('aria-pressed', 'false'); });
    }

    // Use my location
    var locateBtn = document.getElementById('locate-btn');
    if (locateBtn) {
      locateBtn.addEventListener('click', function () {
        if (!navigator.geolocation) {
          say("This browser can't share your location. Pick a suburb instead.");
          return;
        }
        var label = locateBtn.textContent;
        locateBtn.disabled = true;
        locateBtn.textContent = 'Finding you\u2026';

        navigator.geolocation.getCurrentPosition(function (pos) {
          locateBtn.disabled = false;
          locateBtn.textContent = label;
          deactivateChips();
          report('You', 'are', { lat: pos.coords.latitude, lng: pos.coords.longitude });
        }, function () {
          locateBtn.disabled = false;
          locateBtn.textContent = label;
          say("We couldn't get your location. Check your browser's permission, or pick a suburb instead.");
        }, { timeout: 10000, maximumAge: 60000 });
      });
    }

    // Reset
    var resetBtn = document.getElementById('reset-map');
    if (resetBtn) {
      resetBtn.addEventListener('click', function () {
        deactivateChips();
        view.reset();
        say(defaultStatus);
      });
    }

    // Layer checkboxes
    Array.prototype.forEach.call(document.querySelectorAll('[data-layer]'), function (box) {
      box.addEventListener('change', function () {
        view.toggle(box.getAttribute('data-layer'), box.checked);
      });
    });
  }

  /* ---------- Contact page: delivery map ---------- */

  function initFind(el) {
    var map = L.map(el, { zoomSnap: 0.5 });
    addBaseLayers(map, el);
    guardWheel(map);

    var shopLL = L.latLng(PLACES.shop.lat, PLACES.shop.lng);
    var homeBounds = shopLL.toBounds((ZONE2_KM * 2 + 2) * 1000);
    map.fitBounds(homeBounds);

    // Zones start at radius 0 and grow outward when the map scrolls into view.
    var zones = L.layerGroup().addTo(map);
    var zone2 = L.circle(shopLL, { radius: 0, color: COLOURS.jam, weight: 2, dashArray: '6 6',
      fillColor: COLOURS.jam, fillOpacity: 0.07 }).addTo(zones);
    var zone1 = L.circle(shopLL, { radius: 0, color: COLOURS.ink, weight: 2, dashArray: '6 6',
      fillColor: COLOURS.butter, fillOpacity: 0.22 }).addTo(zones);

    var shopMarker = makeMarker(PLACES.shop, 200, '', true).addTo(map);
    var stationLayer = L.layerGroup([makeMarker(PLACES.station, 500, 'pin-paper')]).addTo(map);
    var shelterLayer = L.layerGroup([makeMarker(PLACES.shelter, 700, 'pin-jam')]).addTo(map);
    var layers = { zones: zones, station: stationLayer, shelter: shelterLayer };

    whenVisible(el, function () {
      tween(1700, function (e) {
        zone2.setRadius(ZONE2_KM * 1000 * e);
        zone1.setRadius(ZONE1_KM * 1000 * e);
      }, function () { shopMarker.openPopup(); });
    });

    var pointMarker = null;
    var pointLine = null;

    function clearPoint() {
      if (pointMarker) { map.removeLayer(pointMarker); pointMarker = null; }
      if (pointLine) { map.removeLayer(pointLine); pointLine = null; }
    }

    wireDeliveryPanel({
      show: function (point, label) {
        clearPoint();
        var ll = L.latLng(point.lat, point.lng);
        pointMarker = L.circleMarker(ll, {
          radius: 9, color: COLOURS.ink, weight: 2, fillColor: COLOURS.butter, fillOpacity: 1
        }).addTo(map).bindTooltip(label, {
          permanent: true, direction: 'top', offset: [0, -10], className: 'map-tip'
        });
        pointLine = L.polyline([shopLL, ll], { color: COLOURS.ink, weight: 2, dashArray: '4 6' }).addTo(map);

        map.closePopup();
        map.flyToBounds(L.latLngBounds([shopLL, ll]), {
          padding: [70, 70], maxZoom: 15, duration: 1.1, animate: !reduceMotion
        });
      },
      reset: function () {
        clearPoint();
        map.closePopup();
        map.flyToBounds(homeBounds, { duration: 1, animate: !reduceMotion });
      },
      toggle: function (name, on) {
        var layer = layers[name];
        if (!layer) { return; }
        if (on) { map.addLayer(layer); } else { map.removeLayer(layer); }
      }
    });
  }

  /* ---------- About page: story map ---------- */

  function initStory(el) {
    var map = L.map(el);
    addBaseLayers(map, el);
    guardWheel(map);

    var order = ['kitchen', 'shop', 'shelter'];
    var variants = { kitchen: 'pin-paper', shop: '', shelter: 'pin-jam' };
    var markers = {};
    order.forEach(function (key, i) {
      markers[key] = makeMarker(PLACES[key], 200 + i * 300, variants[key], key === 'shop').addTo(map);
    });

    var points = order.map(function (k) { return [PLACES[k].lat, PLACES[k].lng]; });
    var all = L.latLngBounds(points);
    map.fitBounds(all, { padding: [60, 60] });

    // Routes draw themselves: 2016 kitchen -> shop, then shop -> shelter.
    function drawRoute(from, to, colour, done) {
      var a = L.latLng(PLACES[from].lat, PLACES[from].lng);
      var b = L.latLng(PLACES[to].lat, PLACES[to].lng);
      var line = L.polyline([a, a], { color: colour, weight: 4, dashArray: '2 10', lineCap: 'round' }).addTo(map);
      tween(1600, function (e) {
        line.setLatLngs([a, L.latLng(a.lat + (b.lat - a.lat) * e, a.lng + (b.lng - a.lng) * e)]);
      }, done);
    }

    whenVisible(el, function () {
      drawRoute('kitchen', 'shop', COLOURS.jam, function () {
        drawRoute('shop', 'shelter', COLOURS.ink);
      });
    });

    // Step buttons fly the map between places
    var buttons = document.querySelectorAll('[data-map-step]');
    var caption = document.getElementById('story-caption');
    var captions = {
      all: 'Three places, about half a kilometre apart.',
      kitchen: PLACES.kitchen.name + ' \u2014 ' + PLACES.kitchen.text,
      shop: PLACES.shop.name + ' \u2014 opened in 2021 with the first three paid apprentices.',
      shelter: PLACES.shelter.name + ' \u2014 ' + PLACES.shelter.text
    };

    Array.prototype.forEach.call(buttons, function (button) {
      button.addEventListener('click', function () {
        var step = button.getAttribute('data-map-step');

        Array.prototype.forEach.call(buttons, function (b) {
          b.classList.toggle('is-active', b === button);
          b.setAttribute('aria-pressed', b === button ? 'true' : 'false');
        });
        if (caption) { caption.textContent = captions[step]; }

        map.closePopup();
        if (step === 'all') {
          map.flyToBounds(all, { padding: [60, 60], duration: 1.2, animate: !reduceMotion });
          return;
        }
        map.flyTo([PLACES[step].lat, PLACES[step].lng], 17, { duration: 1.4, animate: !reduceMotion });
        setTimeout(function () { markers[step].openPopup(); }, reduceMotion ? 0 : 1500);
      });
    });
  }

  /* ---------- Start ---------- */

  function start() {
    var find = document.getElementById('map-find');
    var story = document.getElementById('map-story');
    var hasLeaflet = typeof L !== 'undefined';

    if (find) {
      if (hasLeaflet) {
        initFind(find);
      } else {
        // No map, but the distance checker still works
        showFallback(find);
        wireDeliveryPanel({ show: function () {}, reset: function () {}, toggle: function () {} });
        var layout = find.closest('.map-layout');
        if (layout) { layout.classList.add('is-offline'); }
      }
    }

    if (story) {
      if (hasLeaflet) {
        initStory(story);
      } else {
        showFallback(story);
        Array.prototype.forEach.call(document.querySelectorAll('.map-steps, #story-caption'), function (n) { n.hidden = true; });
      }
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start);
  } else {
    start();
  }
})();
